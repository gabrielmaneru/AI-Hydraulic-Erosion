Student Name: Gabriel Mañeru

Special Directions (if any): none

Missing features (if any): none

My experience working on this project:
Interesting Assignment

Hours spent: ~5h

Extra credits: none